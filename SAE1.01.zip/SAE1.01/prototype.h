#include<stdio.h>
#include<stdlib.h>

int creerAdherent(int tabCarte[], int tabPoint[], int tabAge[], int tabEtat[], int tlog, int max);
//int chargement(int tcarte[],int tpoint[],int tage[], int max);
int chargement(int tabAdherent[], int tabCarte[], int tabAge[], int tabEtat[], int size);
void affichage(int tabCarte[], int tabPoint[], int tabAge[], int tabEtat[], int tlog, int saisie);
int rechercher(int tabInt[], int val, int tlog, int *trouve);
void sauvegarder(int tabCarte[], int tabPoint[], int tabAge[], int tabEtat[], int tlog);
void global(void);