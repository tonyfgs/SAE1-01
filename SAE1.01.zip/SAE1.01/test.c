#include"prototype.h"

int main(void)
{
    global();
    return 0;
}